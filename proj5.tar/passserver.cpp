#include "passserver.h"

PassServer::PassServer(size_t size){
htsize = 0;
pw = 0;
ht = new cop4530::HashTable<string,string>(size);
}

PassServer::~PassServer(){
    delete pw;
    delete ht;
    htsize = 0;
}

//bool load(const char *filename): load a password file into the HashTable object. Each line contains a pair of username and encrypted password.
bool PassServer::load(const char *filename){
    return ht->load(filename);
}

//bool addUser(std::pair<string,  string> & kv): add a new username and password.  The password passed in is in plaintext, it should be encrypted before insertion. The pair 
//should not be added if the username already exists in the hash table.
bool PassServer::addUser(std::pair<string,  string> & kv){
    if (ht->contains (kv.first)){
        return false;
    }
    ++htsize;
    return (ht->insert(make_pair(kv.first, encrypt(kv.second))));
}
    
    
//bool addUser(std::pair<string, string> && kv): move version of addUser.
bool PassServer::addUser(std::pair<string, string> && kv){
    if (ht->contains (kv.first)){
        return false;
    }
    ++htsize;
    return (ht->insert(make_pair(kv.first, encrypt(kv.second))));
}
    
//bool removeUser(const string & k): delete an existing user with username k.
bool PassServer::removeUser(const string & k){
    htsize--;
    return ht->remove(k);
}

    
//bool changePassword(const pair<string, string> &p, const string & newpassword): change an existing user's password. Note that both passwords passed in are in plaintext. 
//They should be encrypted before you interact with the hash table. If the user is not in the hash table, return false. If p.second does not match the current password, return 
//false. Also return false if the new password and the old password are the same (i.e., we cannot update the password).
bool PassServer::changePassword(const pair<string, string> &p, const string & newpassword){
    if (ht->match( make_pair(p.first, encrypt(p.second)))){
        if (encrypt(newpassword) == encrypt(p.second)){
            return false;
        }
        ht->insert(make_pair(p.first, encrypt(newpassword)));
        return true;
    }
    return false;
}
    
//bool find(const string & user) const: check if a user exists (if user is in the hash table).
bool PassServer::find(const string & user) const{
    return ht->contains(user);
}

//void dump(): show the structure and contents of the HashTable object to the screen. Same format as the dump() function in the HashTable class template.
void PassServer::dump(){
    ht->dump();
}
    
//size_t size() const: return the size of the HashTable (the number of username/password pairs in the table).
size_t PassServer::size() const{
    return ht->size();
}
    
//bool write_to_file(const char *filename) const: save the username and password combination into a file. Same format as the write_to_file() function in the HashTable class 
//template.
bool PassServer::write_to_file(const char *filename) const{
    return (ht->write_to_file(filename));
}

//string encrypt(const string & str): encrypt the parameter str and return the encrypted string.
string PassServer::encrypt(const string & str) {
    if (pw != 0){
        delete pw;
    }
    char salt[] = "$1$########";
    pw = new char[100];
    string k = str;
    //strcpy(pw, crypt(k.c_str(), salt));
    string result(pw);

    return str;
}