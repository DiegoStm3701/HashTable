#include <iostream>
#include "hashtable.h"
#include "passserver.h"
#include "passserver.cpp"
using namespace std;

void Menu()
{
  cout << "\n\n";
  cout << "l - Load From File" << endl;
  cout << "a - Add User" << endl;
  cout << "r - Remove User" << endl;
  cout << "c - Change User Password" << endl;
  cout << "f - Find User" << endl;
  cout << "d - Dump HashTable" << endl;
  cout << "s - HashTable Size" << endl;
  cout << "w - Write to Password File" << endl;
  cout << "x - Exit program" << endl;
  cout << "\nEnter choice : ";
}



int main(){


char choice;
size_t size;
cout << "Entered preferred hash table capacity (integer): " << endl;
cin >> size;


string username, password, newPassword, filename;
PassServer server(size);

do{
  Menu();
  cin >> choice;
  cout << "choice: " << choice << endl;

  if(choice == 'l'){
    cout<< "Enter password file name to load from: ";
    cin>>filename;
    cout << endl;
    if (server.load(filename.c_str())){
    break;
    }
    else{
    cout<< "Error: cannot open file: "<<filename<<endl;
    }
  }
  else if(choice == 'a'){
    cout << "Enter username: ";
    cin >> username;
    cout << endl;
    cout << "Enter password: ";
    cin >> password;
    cout << endl;

    if(server.addUser(make_pair(username,password))){
    cout << "User " << username << " added." << endl;
    }
    else{
      cout << "*****Error: User already exists. Could not add user." << endl;
    }
  }
  else if(choice == 'r'){
    cout << "Enter username: ";
    cin >> username;
    cout << endl;
    if(server.removeUser(username)){
    cout << "User " << username << " deleted." << endl;
    }
    else{
      cout << "*****Error: User not found.  Could not delete user" << endl;
    }
  }
  else if(choice == 'c'){
    cout << "Enter username: ";
    cin >> username;
    cout << endl;
    cout << "Enter password: ";
    cin >> password;
    cout << endl;
    cout << "Enter new password: ";
    cin >> newPassword;
    cout << endl;

    if (server.changePassword(make_pair(username, password), newPassword)){
      cout << "\nPassword changed for user " << username << endl;
    }
    else{
    cout << "Error: Could not change user password";
    }
  }
  else if(choice == 'f'){
    cout << "Enter username: ";
    cin >> username;
    cout << endl;

    if(server.find(username)){
    cout << "User \'" << username << "\' found." << endl;
    }
    else{
      cout << "User \'" << username << "\' not found." << endl;
    }

    
  }
  else if(choice == 'd'){
    server.dump();
  }
  else if(choice == 's'){
    
    cout << "Size of hashtable: " << server.size() << endl;
  }
  else if(choice == 'w'){
    cout << "Enter password file name to write to: ";
    cin >> filename;
    cout << endl;
    server.write_to_file(filename.c_str());
  }
  else if(choice != 'x'){
    cout << "*****Error: Invalid entry.  Try again." << endl;
  }
}while(choice != 'x');
}









